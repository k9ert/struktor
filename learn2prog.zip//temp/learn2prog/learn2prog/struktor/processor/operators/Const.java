package struktor.processor.operators;

    

    /** $Id: BinaryPlus.java,v 1.1 2000/01/10 17:05:54 uwe Exp $
     * eine Klasse f�r das bin�re Plus
     *
     */



public class Const extends Expr {

	Object value;

	public Const(Object value) {
		this.value = value;
	}



	public Object eval() 
	throws struktor.processor.ProcessorException
	{
 		if (value instanceof Expr)
			return ((Expr)value).eval();
		else
			return value;
	}



    public String toString() {
		return value.toString() ;  }
    
}

