package struktor.processor.operators;

import struktor.processor.*;


/** Diese Operator Klasse entspricht dem ">="-Operator
 */



public class MoreOrEqual extends BinaryExpr {

	public MoreOrEqual(Expr left, Expr right) {
		super(left, right);
	}



	public Object eval() 
	throws struktor.processor.ProcessorException
	{

	// beide Operanden auswerten
	value1 = left.eval();

	value2 = right.eval();
	
	implicitCast();

	// - f�r int
	if ( value1 instanceof Integer && value2 instanceof Integer ) 
	{
		if ( ((Integer)value1).intValue() >= ((Integer)value2).intValue())
			return new Integer(1);
		else
			return new Integer(0);	
	}

	// - f�r double
	if ( value1 instanceof Double && value2 instanceof Double ) 
	{
		if (((Double)value1).doubleValue() >= ((Double)value2).doubleValue())
			return new Double(1);
		else
			return new Double(0);
	}
	
	// Bei anderen Kombinationen soll explizit gecastet werden
	
	// nicht erlaubtes Argument
	throw new ProcessorException("moreOrEqual-operator : illegal operand types");
}

	public String toString() {
		return "("+ left.toString() + " >= " + right.toString() + ")";
	}
}
