Struktor, Ein Struktogrammeditor mit eingebautem Interpreter
Copyright (C) 2000  [Kim Neunert, k9ert@gmx.de]

Dieses Programm ist freie Software. Sie k�nnen es unter
den Bedingungen der GNU General Public License, wie von der
Free Software Foundation herausgegeben, weitergeben und/oder
modifizieren, entweder unter Version 2 der Lizenz oder (wenn
Sie es w�nschen) jeder sp�teren Version.

Die Ver�ffentlichung dieses Programms erfolgt in der
Hoffnung, da� es Ihnen von Nutzen sein wird, aber OHNE JEDE
GEW�HRLEISTUNG - sogar ohne die implizite Gew�hrleistung
der MARKTREIFE oder der EIGNUNG F�R EINEN BESTIMMTEN ZWECK.
Details finden Sie in der GNU General Public License.

Sie sollten eine Kopie der GNU General Public License zusammen
mit diesem Programm erhalten haben. Falls nicht, schreiben Sie
an die Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
MA 02139, USA.

Wer interessante Struktogramme erstellt, bitte zuschicken !

Viel Spa�

15.Oktober 2001
  .
|<|.\\

ToDo:
- Strukturen implementieren
- Sch�ner ausschauenlassen